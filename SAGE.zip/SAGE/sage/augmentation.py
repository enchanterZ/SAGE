"""
sage/augmentation.py
Semantic Utility Augmentation                           [Sec. 3.2]

For each labeled sample (x, y) ∈ L_t, generates M_t candidates via a
mixture of conventional transforms and Stable Diffusion img2img, then
scores each candidate in the frozen CLIP space using:
  - A_cls : class alignment                             [Eq. 7]
  - P_ins : instance preservation                       [Eq. 8]
  - N_R   : relative novelty                            [Eq. 9]

A learned augmentation head g_ω^aug predicts per-candidate weights
used to re-weight the supervised cross-entropy loss.               [Eq. 11–13]
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as T
from typing import List, Optional, Tuple

from .utils import CLIPEncoder, pairwise_cosine


# ──────────────────────────────────────────────
# Augmentation candidate generation
# ──────────────────────────────────────────────

class ConventionalAugmentation(nn.Module):
    """Standard photometric + geometric augmentations (p_T branch)."""

    def __init__(self, image_size: int = 224):
        super().__init__()
        self.aug = T.Compose([
            T.RandomResizedCrop(image_size, scale=(0.6, 1.0)),
            T.RandomHorizontalFlip(),
            T.ColorJitter(brightness=0.4, contrast=0.4,
                          saturation=0.2, hue=0.1),
            T.RandomGrayscale(p=0.1),
            T.GaussianBlur(kernel_size=23, sigma=(0.1, 2.0)),
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (C, H, W) single image tensor in [0,1]."""
        return self.aug(x)


class StableDiffusionAugmentation:
    """
    Stable Diffusion img2img branch (p_sd).
    Deferred import to avoid loading the model unless SD is needed.
    """

    def __init__(self, model_id: str, device: str = "cuda"):
        from diffusers import StableDiffusionImg2ImgPipeline
        import torch

        self.pipe = StableDiffusionImg2ImgPipeline.from_pretrained(
            model_id, torch_dtype=torch.float16
        ).to(device)
        self.pipe.safety_checker = None          # disable for training speed
        self.device = device

    @torch.no_grad()
    def __call__(
        self,
        pil_image,
        class_name: str,
        strength: float = 0.6,
        num_inference_steps: int = 20,
    ):
        prompt = f"a high quality photo of a {class_name}"
        result = self.pipe(
            prompt=prompt,
            image=pil_image,
            strength=strength,
            num_inference_steps=num_inference_steps,
        )
        return result.images[0]


# ──────────────────────────────────────────────
# Scoring functions (Eqs. 7–9)
# ──────────────────────────────────────────────

def class_alignment(
    v_aug: torch.Tensor,   # (D,) normalised aug embedding
    u_y: torch.Tensor,     # (D,) normalised text embedding for class y
) -> torch.Tensor:
    """A_cls(x', y) = cos(v(x'), u(y))               [Eq. 7]"""
    return F.cosine_similarity(v_aug.unsqueeze(0), u_y.unsqueeze(0)).squeeze()


def instance_preservation(
    v_aug: torch.Tensor,   # (D,)
    v_orig: torch.Tensor,  # (D,)
) -> torch.Tensor:
    """P_ins(x', x) = cos(v(x'), v(x))               [Eq. 8]"""
    return F.cosine_similarity(v_aug.unsqueeze(0), v_orig.unsqueeze(0)).squeeze()


def relative_novelty(
    v_aug: torch.Tensor,          # (D,)
    accepted_embeddings: Optional[torch.Tensor],  # (K, D) or None
) -> torch.Tensor:
    """
    N_R(x'; A_x) = 1                        if A_x = ∅
                 = min_{x̃ ∈ A_x} (1 - cos(v(x'), v(x̃)))   otherwise
                                                            [Eq. 9]
    """
    if accepted_embeddings is None or len(accepted_embeddings) == 0:
        return torch.tensor(1.0, device=v_aug.device)
    sims = F.cosine_similarity(v_aug.unsqueeze(0), accepted_embeddings)  # (K,)
    return 1.0 - sims.max()


# ──────────────────────────────────────────────
# Augmentation head  g_ω^aug
# ──────────────────────────────────────────────

class AugmentationHead(nn.Module):
    """
    g_ω^aug : ξ_t^aug(x') → score s_t(x')            [Eq. 11]

    Input  ξ_t^aug = [ϕ_t ; ψ_t^aug]
      ϕ_t      : round-state feature  (state_dim,)
      ψ_t^aug  : [A_cls, P_ins, N_R]  (3,)
    """

    def __init__(self, state_dim: int = 6, hidden: int = 64):
        super().__init__()
        in_dim = state_dim + 3          # ϕ_t || ψ_t^aug
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, xi: torch.Tensor) -> torch.Tensor:
        """
        Args:
            xi: (N, state_dim + 3)
        Returns:
            scores: (N,)
        """
        return self.net(xi).squeeze(-1)


# ──────────────────────────────────────────────
# Main augmentation module
# ──────────────────────────────────────────────

class SemanticUtilityAugmentation(nn.Module):
    """
    Wraps candidate generation + scoring + weight computation.

    Usage:
        aug = SemanticUtilityAugmentation(clip_encoder, aug_head, ...)
        loss_aug, mean_w = aug.compute_aug_loss(
            classifier, labeled_batch, class_names, phi_t, alpha_t, M_t
        )
    """

    def __init__(
        self,
        clip: CLIPEncoder,
        aug_head: AugmentationHead,
        sd_aug: Optional[StableDiffusionAugmentation] = None,
        image_size: int = 224,
        device: str = "cuda",
    ):
        super().__init__()
        self.clip = clip
        self.aug_head = aug_head
        self.conv_aug = ConventionalAugmentation(image_size)
        self.sd_aug = sd_aug
        self.device = device

    # ── candidate generation ────────────────────────────────

    def _generate_candidates(
        self,
        x: torch.Tensor,          # (C, H, W)
        y_name: str,
        alpha_t: float,
        M_t: int,
    ) -> List[torch.Tensor]:
        """
        Sample M_t candidates from the mixture
        p_aug(·|x, y; α_t) = (1-α_t) p_T + α_t p_sd         [Eq. 5–6]
        """
        import random
        from PIL import Image
        import torchvision.transforms.functional as TF

        candidates: List[torch.Tensor] = []
        for _ in range(M_t):
            use_sd = (self.sd_aug is not None) and (random.random() < alpha_t)
            if use_sd:
                pil = TF.to_pil_image(x.cpu())
                pil_aug = self.sd_aug(pil, y_name, strength=alpha_t)
                x_aug = TF.to_tensor(pil_aug).to(self.device)
            else:
                x_aug = self.conv_aug(x)
            candidates.append(x_aug)
        return candidates

    # ── weight computation ──────────────────────────────────

    def compute_weights(
        self,
        x: torch.Tensor,           # (C, H, W) original image
        y_idx: int,
        candidates: List[torch.Tensor],
        u_all: torch.Tensor,       # (C_cls, D) text embeddings
        phi_t: torch.Tensor,       # (state_dim,) round-state feature
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Compute normalised weights w_t(x') for each candidate.  [Eq. 12]

        Returns:
            weights: (M_t,) normalised nonneg weights
            raw_scores: (M_t,)
        """
        v_orig = self.clip.visual(x.unsqueeze(0)).squeeze(0)   # (D,)
        u_y = u_all[y_idx]                                     # (D,)

        accepted_embs: List[torch.Tensor] = []
        psi_list: List[torch.Tensor] = []

        for xm in candidates:
            v_m = self.clip.visual(xm.unsqueeze(0)).squeeze(0)

            a_cls = class_alignment(v_m, u_y)
            p_ins = instance_preservation(v_m, v_orig)
            n_r = relative_novelty(
                v_m,
                torch.stack(accepted_embs) if accepted_embs else None
            )

            psi = torch.stack([a_cls, p_ins, n_r])              # (3,)
            psi_list.append(psi)
            accepted_embs.append(v_m.detach())

        psi_stack = torch.stack(psi_list)                       # (M, 3)
        phi_exp = phi_t.unsqueeze(0).expand(len(candidates), -1)
        xi = torch.cat([phi_exp, psi_stack], dim=-1)            # (M, state+3)

        raw = self.aug_head(xi)                                 # (M,)
        w_tilde = F.relu(raw)
        w = w_tilde / (w_tilde.mean() + 1e-8)                  # normalise [Eq.12]
        return w, raw

    # ── supervised loss  ────────────────────────────────────

    def compute_aug_loss(
        self,
        classifier,
        images: torch.Tensor,      # (N, C, H, W)
        labels: torch.Tensor,      # (N,)
        class_names: List[str],
        phi_t: torch.Tensor,       # (state_dim,)
        alpha_t: float,
        M_t: int,
        lambda_aug: float = 0.5,
    ) -> Tuple[torch.Tensor, float]:
        """
        L_sup = CE(f_t(x), y)
              + λ_aug · Σ w_t(x') CE(f_t(x'), y)           [Eq. 13]

        Returns:
            loss: scalar tensor
            mean_w: float (used for reward computation)
        """
        u_all = self.clip.textual(class_names)                  # (C, D)

        ce = nn.CrossEntropyLoss(reduction="none")
        base_loss = ce(classifier(images), labels).mean()

        aug_loss = torch.tensor(0.0, device=self.device)
        all_weights: List[float] = []

        for i in range(len(images)):
            x_i = images[i]
            y_i = labels[i].item()
            y_name = class_names[y_i]

            candidates = self._generate_candidates(x_i, y_name, alpha_t, M_t)
            weights, _ = self.compute_weights(x_i, y_i, candidates, u_all, phi_t)

            for m, (xm, wm) in enumerate(zip(candidates, weights)):
                logits_m = classifier(xm.unsqueeze(0))
                loss_m = ce(logits_m, labels[i:i+1])
                aug_loss = aug_loss + wm * loss_m.squeeze()

            all_weights.extend(weights.detach().tolist())

        aug_loss = aug_loss / (len(images) * M_t)
        total_loss = base_loss + lambda_aug * aug_loss
        mean_w = sum(all_weights) / max(len(all_weights), 1)

        return total_loss, mean_w
