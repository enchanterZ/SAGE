"""
sage/datasets.py
Dataset builders for fine-grained image classification benchmarks.

Supported:
  - CUB-200-2011
  - Stanford Cars
  - FGVC-Aircraft
  - Oxford Pets

Each returns (train_dataset, val_dataset, class_names).
"""

from __future__ import annotations

import os
import json
from pathlib import Path
from typing import List, Tuple, Dict, Any

import torch
from torch.utils.data import Dataset
from torchvision import datasets, transforms
from PIL import Image


# ──────────────────────────────────────────────
# Standard transforms
# ──────────────────────────────────────────────

def get_transforms(image_size: int = 224, is_train: bool = True):
    normalize = transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225],
    )
    if is_train:
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize,
        ])
    return transforms.Compose([
        transforms.Resize(int(image_size * 1.14)),
        transforms.CenterCrop(image_size),
        transforms.ToTensor(),
        normalize,
    ])


# ──────────────────────────────────────────────
# CUB-200-2011
# ──────────────────────────────────────────────

class CUB200Dataset(Dataset):
    """
    CUB-200-2011 fine-grained bird classification.
    Expected directory layout:
        root/
          images/
          image_class_labels.txt
          images.txt
          train_test_split.txt
          classes.txt
    """

    def __init__(self, root: str, train: bool = True,
                 transform=None):
        self.root = Path(root)
        self.transform = transform

        # Load file lists
        img_id_to_path: Dict[int, str] = {}
        with open(self.root / "images.txt") as f:
            for line in f:
                iid, path = line.strip().split()
                img_id_to_path[int(iid)] = path

        img_id_to_label: Dict[int, int] = {}
        with open(self.root / "image_class_labels.txt") as f:
            for line in f:
                iid, lbl = line.strip().split()
                img_id_to_label[int(iid)] = int(lbl) - 1   # 0-indexed

        train_flags: Dict[int, int] = {}
        with open(self.root / "train_test_split.txt") as f:
            for line in f:
                iid, flag = line.strip().split()
                train_flags[int(iid)] = int(flag)

        self.class_names: List[str] = []
        with open(self.root / "classes.txt") as f:
            for line in f:
                _, name = line.strip().split(maxsplit=1)
                self.class_names.append(name.replace("_", " "))

        self.samples: List[Tuple[str, int]] = []
        for iid, path in img_id_to_path.items():
            is_train = (train_flags[iid] == 1)
            if is_train == train:
                full_path = str(self.root / "images" / path)
                self.samples.append((full_path, img_id_to_label[iid]))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int):
        path, label = self.samples[idx]
        img = Image.open(path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, label


# ──────────────────────────────────────────────
# Generic ImageFolder fallback
# ──────────────────────────────────────────────

class ImageFolderDataset(Dataset):
    """
    Wraps torchvision.datasets.ImageFolder.
    """

    def __init__(self, root: str, transform=None):
        self._ds = datasets.ImageFolder(root, transform=transform)
        self.class_names: List[str] = self._ds.classes

    def __len__(self):
        return len(self._ds)

    def __getitem__(self, idx):
        return self._ds[idx]


# ──────────────────────────────────────────────
# Factory
# ──────────────────────────────────────────────

def build_dataset(
    cfg: Dict[str, Any],
) -> Tuple[Dataset, Dataset, List[str]]:
    """
    Returns:
        train_dataset, val_dataset, class_names
    """
    ds_cfg = cfg["dataset"]
    name: str = ds_cfg["name"].lower()
    root: str = ds_cfg["root"]
    image_size: int = ds_cfg.get("image_size", 224)

    train_tf = get_transforms(image_size, is_train=True)
    val_tf = get_transforms(image_size, is_train=False)

    if name == "cub200":
        train_ds = CUB200Dataset(root, train=True, transform=train_tf)
        val_ds = CUB200Dataset(root, train=False, transform=val_tf)
        class_names = train_ds.class_names

    elif name in ("stanford_cars", "cars"):
        # torchvision >= 0.12 has StanfordCars
        from torchvision.datasets import StanfordCars
        train_ds = StanfordCars(root, split="train", transform=train_tf, download=False)
        val_ds = StanfordCars(root, split="test", transform=val_tf, download=False)
        class_names = [c.replace("_", " ") for c in train_ds.classes]

    elif name in ("aircraft", "fgvc_aircraft"):
        from torchvision.datasets import FGVCAircraft
        train_ds = FGVCAircraft(root, split="train", transform=train_tf, download=False)
        val_ds = FGVCAircraft(root, split="val", transform=val_tf, download=False)
        class_names = train_ds.classes

    elif name in ("oxford_pets", "pets"):
        from torchvision.datasets import OxfordIIITPet
        train_ds = OxfordIIITPet(root, split="trainval", transform=train_tf, download=False)
        val_ds = OxfordIIITPet(root, split="test", transform=val_tf, download=False)
        class_names = train_ds.classes

    else:
        # Fallback: ImageFolder  (train/ and val/ subdirs expected)
        train_ds = ImageFolderDataset(os.path.join(root, "train"), transform=train_tf)
        val_ds = ImageFolderDataset(os.path.join(root, "val"), transform=val_tf)
        class_names = train_ds.class_names

    print(f"[dataset] {name}: {len(train_ds)} train, "
          f"{len(val_ds)} val, {len(class_names)} classes")
    return train_ds, val_ds, class_names
