"""
sage/model.py
Task classifier:  f_t(x) = h_t(z_c(x))               [Eq. 1]

The visual encoder z_c is initialised from the CLIP visual encoder
and is fine-tuned during active learning.  The classification head h_t
is a lightweight linear layer that is re-initialised whenever the
label set changes significantly (optional; controlled by config).
"""

from __future__ import annotations

import open_clip
import torch
import torch.nn as nn
import torch.nn.functional as F


class TaskClassifier(nn.Module):
    """
    f_t(x) = h_t(z_c(x))                              [Eq. 1]

    Args:
        clip_model:    OpenCLIP model name (e.g. "ViT-B-32")
        pretrained:    OpenCLIP pretrained weights (e.g. "openai")
        num_classes:   number of fine-grained categories
        embed_dim:     CLIP visual embedding dimension (auto-detected)
    """

    def __init__(
        self,
        clip_model: str = "ViT-B-32",
        pretrained: str = "openai",
        num_classes: int = 200,
    ):
        super().__init__()
        clip, _, _ = open_clip.create_model_and_transforms(
            clip_model, pretrained=pretrained
        )
        # Trainable visual encoder z_c
        self.encoder = clip.visual
        embed_dim: int = self.encoder.output_dim

        # Trainable classification head h_t
        self.head = nn.Linear(embed_dim, num_classes)
        nn.init.normal_(self.head.weight, std=0.02)
        nn.init.zeros_(self.head.bias)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Return raw (non-normalised) visual features z_c(x)."""
        return self.encoder(x)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Returns:
            logits: (N, num_classes)
        """
        z = self.encode(x)
        return self.head(z)

    def predict_proba(self, x: torch.Tensor) -> torch.Tensor:
        """Softmax class probabilities p_t(c|x)."""
        return F.softmax(self.forward(x), dim=-1)
