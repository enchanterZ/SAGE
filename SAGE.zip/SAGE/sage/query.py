"""
sage/query.py
Learned Query Utility                                   [Sec. 3.3]

Scores unlabeled samples with a learned head g_ω^qry that combines:
  - A_abs(x)        : absolute semantic consistency    [Eq. 14]
  - H(x)            : predictive uncertainty           [Eq. 15]
  - Div(x | S_t^k)  : diversity w.r.t. partial batch  [Eq. 16]

Sequential selection:
  x_1* = argmax_{x ∈ U_t}       Q_base(x)             [Eq. 20]
  x_{k+1}* = argmax_{x ∈ U_t\S} Q_seq(x, S_t^k)      [Eq. 21]
  Q_seq = (1-p_t) Q_base + p_t Div(x | S_t^k)         [Eq. 19]
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Set

from .utils import CLIPEncoder, compute_entropy


# ──────────────────────────────────────────────
# Query head  g_ω^qry
# ──────────────────────────────────────────────

class QueryHead(nn.Module):
    """
    g_ω^qry : ξ_t^qry(x) → δ̂_t(x)                   [Eq. 18]

    Input ξ_t^qry = [ϕ_t ; ψ_t^qry]
      ϕ_t     : round-state feature  (state_dim,)
      ψ_t^qry : [A_abs, H, Div]      (3,)
    """

    def __init__(self, state_dim: int = 6, hidden: int = 64):
        super().__init__()
        in_dim = state_dim + 3
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, xi: torch.Tensor) -> torch.Tensor:
        """
        Args:
            xi: (N, state_dim + 3)
        Returns:
            utility scores: (N,)
        """
        return self.net(xi).squeeze(-1)


# ──────────────────────────────────────────────
# Diversity computation  [Eq. 16]
# ──────────────────────────────────────────────

def compute_diversity(
    v_x: torch.Tensor,              # (D,) embedding of candidate
    selected_embeddings: torch.Tensor | None,  # (K, D) or None
) -> torch.Tensor:
    """
    Red(x | S_t^k) = 0                                 if S_t^k = ∅
                   = max_{z ∈ V(S_t^k)} cos(v(x), z)  otherwise
    Div(x | S_t^k) = 1 - Red(x | S_t^k)               [Eq. 16]
    """
    if selected_embeddings is None or len(selected_embeddings) == 0:
        return torch.tensor(1.0, device=v_x.device)
    sims = F.cosine_similarity(v_x.unsqueeze(0), selected_embeddings)
    redundancy = sims.max()
    return 1.0 - redundancy


# ──────────────────────────────────────────────
# Main query utility module
# ──────────────────────────────────────────────

class LearnedQueryUtility:
    """
    Evaluates unlabeled pool and selects b_t samples via sequential
    greedy selection.

    Usage:
        lqu = LearnedQueryUtility(clip, query_head)
        query_batch = lqu.select(
            unlabeled_images, classifier, class_names,
            phi_t, b_t, p_t
        )
    """

    def __init__(
        self,
        clip: CLIPEncoder,
        query_head: QueryHead,
        device: str = "cuda",
    ):
        self.clip = clip
        self.query_head = query_head
        self.device = device

    # ── feature computation ────────────────────────────────

    @torch.no_grad()
    def _build_descriptors(
        self,
        images: torch.Tensor,      # (N, C, H, W)
        classifier,
        class_names: List[str],
        phi_t: torch.Tensor,       # (state_dim,)
    ):
        """
        Compute per-sample features for all N unlabeled images.

        Returns:
            v_all   : (N, D) CLIP visual embeddings
            a_abs   : (N,)   absolute semantic consistency    [Eq. 14]
            entropy : (N,)   predictive uncertainty           [Eq. 15]
        """
        u_all = self.clip.textual(class_names)               # (C, D)

        # Batch CLIP embeddings
        v_all = self.clip.visual(images)                     # (N, D)

        # A_abs(x) = max_c cos(v(x), u(c))                  [Eq. 14]
        a_abs = (v_all @ u_all.T).max(dim=-1).values         # (N,)

        # H(x)                                              [Eq. 15]
        logits = classifier(images)                          # (N, C)
        entropy = compute_entropy(logits)                    # (N,)

        return v_all, a_abs, entropy

    # ── Q_base score ──────────────────────────────────────

    @torch.no_grad()
    def _q_base(
        self,
        v_all: torch.Tensor,       # (N, D)
        a_abs: torch.Tensor,       # (N,)
        entropy: torch.Tensor,     # (N,)
        phi_t: torch.Tensor,       # (state_dim,)
        selected_embs: torch.Tensor | None,
    ) -> torch.Tensor:
        """
        Q_base(x) = δ̂_t(x)       (Div computed w.r.t. S so far) [Eq. 18]
        """
        N = len(v_all)
        div = torch.stack([
            compute_diversity(v_all[i], selected_embs)
            for i in range(N)
        ])                                                   # (N,)

        psi = torch.stack([a_abs, entropy, div], dim=-1)    # (N, 3)
        phi_exp = phi_t.unsqueeze(0).expand(N, -1)
        xi = torch.cat([phi_exp, psi], dim=-1)              # (N, state+3)

        return self.query_head(xi)                           # (N,)

    # ── sequential selection ───────────────────────────────

    @torch.no_grad()
    def select(
        self,
        images: torch.Tensor,      # (N, C, H, W) unlabeled pool
        classifier,
        class_names: List[str],
        phi_t: torch.Tensor,       # (state_dim,)
        b_t: int,                  # query budget for this round
        p_t: float,                # diversity–utility trade-off weight
    ) -> List[int]:
        """
        Returns:
            indices of selected samples in [0, N)            [Eqs. 20–21]
        """
        b_t = min(b_t, len(images))
        classifier.eval()

        v_all, a_abs, entropy = self._build_descriptors(
            images, classifier, class_names, phi_t
        )

        selected_indices: List[int] = []
        selected_embs: torch.Tensor | None = None
        remaining: Set[int] = set(range(len(images)))

        for k in range(b_t):
            rem = list(remaining)
            v_rem = v_all[rem]          # (R, D)
            a_rem = a_abs[rem]          # (R,)
            h_rem = entropy[rem]        # (R,)

            # Compute diversity for each remaining sample
            div_rem = torch.stack([
                compute_diversity(v_all[i], selected_embs)
                for i in rem
            ])                                               # (R,)

            psi = torch.stack([a_rem, h_rem, div_rem], dim=-1)
            phi_exp = phi_t.unsqueeze(0).expand(len(rem), -1)
            xi = torch.cat([phi_exp, psi], dim=-1)

            q_base = self.query_head(xi)                    # (R,)

            if k == 0:
                # x_1* = argmax Q_base(x)                  [Eq. 20]
                best_local = q_base.argmax().item()
            else:
                # Q_seq = (1-p_t) Q_base + p_t Div         [Eq. 19]
                q_seq = (1 - p_t) * q_base + p_t * div_rem
                best_local = q_seq.argmax().item()

            best_global = rem[best_local]
            selected_indices.append(best_global)
            remaining.discard(best_global)

            # Update selected embeddings V(S_t^{k+1})
            new_emb = v_all[best_global].unsqueeze(0)       # (1, D)
            if selected_embs is None:
                selected_embs = new_emb
            else:
                selected_embs = torch.cat([selected_embs, new_emb], dim=0)

        return selected_indices                              # Q_t = S_t^{b_t}
