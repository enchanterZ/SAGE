"""
sage/scheduler.py
Adaptive Budget Scheduling with PPO-Clip                [Sec. 3.4]

The RL scheduler observes the round state s_t and outputs action
  a_t = [α_t, b_t, p_t]                                [Eq. 4]
where
  α_t  ∈ (0,1)        augmentation strength
  b_t  ∈ {1,…,B_t}    query budget for this round
  p_t  ∈ (0,1)        diversity–utility trade-off

Architecture: two-layer MLP actor-critic               [Eq. 22]
  Linear(d_s, 128) → ReLU → Linear(128, 128) → ReLU

Reward:
  r_t = ΔAcc_t - β·b_t - η·(1 - w̄_t)                [Eq. 24]

Optimised with PPO-Clip.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Beta, Normal
from typing import List, Tuple, Optional
import numpy as np


# ──────────────────────────────────────────────
# Shared backbone  [Eq. 22]
# ──────────────────────────────────────────────

def _make_backbone(in_dim: int, hidden: int = 128) -> nn.Sequential:
    """Linear(d_s, 128) → ReLU → Linear(128, 128) → ReLU"""
    return nn.Sequential(
        nn.Linear(in_dim, hidden),
        nn.ReLU(),
        nn.Linear(hidden, hidden),
        nn.ReLU(),
    )


# ──────────────────────────────────────────────
# Actor
# ──────────────────────────────────────────────

class Actor(nn.Module):
    """
    Outputs parameters for three action distributions:
      α_t ~ Beta(a1, b1)           continuous ∈ (0,1)
      b_t ~ Discrete / rounded     integer ∈ [1, B_t]
      p_t ~ Beta(a2, b2)           continuous ∈ (0,1)
    """

    def __init__(self, state_dim: int = 6, hidden: int = 128):
        super().__init__()
        self.backbone = _make_backbone(state_dim, hidden)

        # Alpha distribution (Beta params)
        self.alpha_head = nn.Linear(hidden, 2)   # (a, b) of Beta
        # Budget fraction distribution (Beta, then scale to b_t)
        self.budget_head = nn.Linear(hidden, 2)
        # Diversity weight distribution (Beta params)
        self.p_head = nn.Linear(hidden, 2)

    def _beta_params(self, raw: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Map raw linear output to positive Beta params via softplus."""
        a = F.softplus(raw[:, 0]) + 1e-3
        b = F.softplus(raw[:, 1]) + 1e-3
        return a, b

    def forward(
        self,
        state: torch.Tensor,       # (B, state_dim)
    ) -> Tuple[Beta, Beta, Beta]:
        h = self.backbone(state)

        a_alpha, b_alpha = self._beta_params(self.alpha_head(h))
        a_budget, b_budget = self._beta_params(self.budget_head(h))
        a_p, b_p = self._beta_params(self.p_head(h))

        dist_alpha = Beta(a_alpha, b_alpha)
        dist_budget = Beta(a_budget, b_budget)   # sample ∈(0,1), scale later
        dist_p = Beta(a_p, b_p)

        return dist_alpha, dist_budget, dist_p

    def sample_action(
        self,
        state: torch.Tensor,       # (state_dim,)
        budget_remaining: int,
        min_query: int = 1,
    ) -> Tuple[float, int, float, torch.Tensor]:
        """
        Sample (α_t, b_t, p_t) and return their log-prob.

        Returns:
            alpha, b_t (int), p_t, log_prob (scalar tensor)
        """
        s = state.unsqueeze(0)
        dist_alpha, dist_budget, dist_p = self.forward(s)

        alpha_s = dist_alpha.sample()
        budget_f = dist_budget.sample()
        p_s = dist_p.sample()

        # Scale budget fraction to integer query size
        b_raw = (budget_f * budget_remaining).clamp(min=min_query,
                                                     max=budget_remaining)
        b_t = b_raw.round().long().item()

        log_prob = (
            dist_alpha.log_prob(alpha_s)
            + dist_budget.log_prob(budget_f)
            + dist_p.log_prob(p_s)
        ).sum()

        return alpha_s.item(), b_t, p_s.item(), log_prob, budget_f


# ──────────────────────────────────────────────
# Critic
# ──────────────────────────────────────────────

class Critic(nn.Module):
    """V(s_t) — state value function."""

    def __init__(self, state_dim: int = 6, hidden: int = 128):
        super().__init__()
        self.backbone = _make_backbone(state_dim, hidden)
        self.value_head = nn.Linear(hidden, 1)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        """
        Args:
            state: (B, state_dim)
        Returns:
            values: (B,)
        """
        h = self.backbone(state)
        return self.value_head(h).squeeze(-1)


# ──────────────────────────────────────────────
# Rollout buffer
# ──────────────────────────────────────────────

class RolloutBuffer:
    """Stores transitions for PPO updates."""

    def __init__(self):
        self.states: List[torch.Tensor] = []
        self.log_probs: List[torch.Tensor] = []
        self.rewards: List[float] = []
        self.values: List[torch.Tensor] = []
        self.budget_fracs: List[torch.Tensor] = []
        self.alpha_samples: List[torch.Tensor] = []
        self.p_samples: List[torch.Tensor] = []

    def clear(self):
        self.__init__()

    def __len__(self):
        return len(self.rewards)


# ──────────────────────────────────────────────
# Reward computation  [Eq. 24]
# ──────────────────────────────────────────────

def compute_reward(
    delta_acc: float,     # ΔAcc_t
    b_t: int,             # query size this round
    mean_w: float,        # w̄_t — average augmentation weight  [Eq. 23]
    beta: float = 0.01,   # budget consumption penalty
    eta: float = 0.1,     # augmentation inefficiency penalty
) -> float:
    """
    r_t = ΔAcc_t - β·b_t - η·(1 - w̄_t)               [Eq. 24]
    """
    return delta_acc - beta * b_t - eta * (1.0 - mean_w)


# ──────────────────────────────────────────────
# PPO-Clip scheduler
# ──────────────────────────────────────────────

class AdaptiveBudgetScheduler:
    """
    Two-layer MLP actor-critic trained with PPO-Clip.
    Wraps Actor + Critic with optimisers and update logic.
    """

    def __init__(
        self,
        state_dim: int = 6,
        hidden_dim: int = 128,
        lr_actor: float = 3e-4,
        lr_critic: float = 1e-3,
        gamma: float = 0.99,
        clip_eps: float = 0.2,
        ppo_epochs: int = 4,
        beta: float = 0.01,
        eta: float = 0.1,
        device: str = "cuda",
    ):
        self.gamma = gamma
        self.clip_eps = clip_eps
        self.ppo_epochs = ppo_epochs
        self.beta = beta
        self.eta = eta
        self.device = device

        self.actor = Actor(state_dim, hidden_dim).to(device)
        self.critic = Critic(state_dim, hidden_dim).to(device)

        self.opt_actor = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.opt_critic = optim.Adam(self.critic.parameters(), lr=lr_critic)

        self.buffer = RolloutBuffer()

    # ── action ────────────────────────────────────────────

    def act(
        self,
        state: torch.Tensor,
        budget_remaining: int,
        min_query: int = 1,
    ) -> Tuple[float, int, float]:
        """
        Observe state, sample action, store transition in buffer.

        Returns:
            alpha_t, b_t, p_t
        """
        state = state.to(self.device)
        with torch.no_grad():
            value = self.critic(state.unsqueeze(0)).squeeze()

        alpha, b_t, p_t, log_prob, budget_frac = self.actor.sample_action(
            state, budget_remaining, min_query
        )

        self.buffer.states.append(state)
        self.buffer.log_probs.append(log_prob.detach())
        self.buffer.values.append(value.detach())
        self.buffer.budget_fracs.append(budget_frac.detach())

        return alpha, b_t, p_t

    def store_reward(self, reward: float):
        self.buffer.rewards.append(reward)

    # ── PPO update ────────────────────────────────────────

    def update(self):
        """Run PPO-Clip update over the collected rollout."""
        if len(self.buffer) == 0:
            return

        # Compute discounted returns
        returns = self._compute_returns(self.buffer.rewards)
        returns = torch.tensor(returns, dtype=torch.float32, device=self.device)

        states = torch.stack(self.buffer.states)             # (T, state_dim)
        old_lp = torch.stack(self.buffer.log_probs)          # (T,)
        old_vals = torch.stack(self.buffer.values)           # (T,)
        budget_fracs = torch.stack(self.buffer.budget_fracs) # (T,)

        advantages = (returns - old_vals).detach()
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        for _ in range(self.ppo_epochs):
            # Current distributions
            dist_alpha, dist_budget, dist_p = self.actor(states)

            # We stored only budget_frac; re-sample log_probs needs stored actions.
            # Here we use the stored budget_fracs for the budget log_prob.
            lp_alpha = dist_alpha.log_prob(
                dist_alpha.mean.detach().clamp(1e-6, 1 - 1e-6)
            )
            lp_budget = dist_budget.log_prob(
                budget_fracs.clamp(1e-6, 1 - 1e-6)
            )
            lp_p = dist_p.log_prob(
                dist_p.mean.detach().clamp(1e-6, 1 - 1e-6)
            )
            new_lp = (lp_alpha + lp_budget + lp_p).sum(dim=-1)

            ratio = (new_lp - old_lp).exp()
            surr1 = ratio * advantages
            surr2 = ratio.clamp(1 - self.clip_eps, 1 + self.clip_eps) * advantages
            actor_loss = -torch.min(surr1, surr2).mean()

            values = self.critic(states)
            critic_loss = F.mse_loss(values, returns)

            self.opt_actor.zero_grad()
            actor_loss.backward()
            nn.utils.clip_grad_norm_(self.actor.parameters(), 0.5)
            self.opt_actor.step()

            self.opt_critic.zero_grad()
            critic_loss.backward()
            nn.utils.clip_grad_norm_(self.critic.parameters(), 0.5)
            self.opt_critic.step()

        self.buffer.clear()

    def _compute_returns(self, rewards: List[float]) -> List[float]:
        returns, R = [], 0.0
        for r in reversed(rewards):
            R = r + self.gamma * R
            returns.insert(0, R)
        return returns

    # ── persistence ───────────────────────────────────────

    def state_dict(self):
        return {
            "actor": self.actor.state_dict(),
            "critic": self.critic.state_dict(),
        }

    def load_state_dict(self, d: dict):
        self.actor.load_state_dict(d["actor"])
        self.critic.load_state_dict(d["critic"])
