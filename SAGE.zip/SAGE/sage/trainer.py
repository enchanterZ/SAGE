"""
sage/trainer.py
SAGETrainer — orchestrates the full closed-loop active learning process.

Per-round procedure:
  1. Scheduler outputs (α_t, b_t, p_t)
  2. SemanticUtilityAugmentation trains the classifier (L_sup)     [Eq.13]
  3. LearnedQueryUtility selects b_t new samples sequentially      [Eq.20–21]
  4. Oracle annotates Q_t; labeled set, pool, budget updated
  5. Reward r_t computed and returned to RL scheduler              [Eq.24]
  6. PPO update after each round
"""

from __future__ import annotations

import os
import copy
import random
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Subset, Dataset
from typing import List, Optional, Dict, Any
from tqdm import tqdm

from .model import TaskClassifier
from .augmentation import SemanticUtilityAugmentation, AugmentationHead
from .query import LearnedQueryUtility, QueryHead
from .scheduler import AdaptiveBudgetScheduler, compute_reward
from .utils import CLIPEncoder, compute_accuracy, build_round_state


class SAGETrainer:
    """
    Args:
        cfg:         flat dict parsed from YAML config
        dataset:     full dataset (train + unlabeled pool)
        val_dataset: held-out validation set
        class_names: list of class name strings (len = num_classes)
    """

    def __init__(
        self,
        cfg: Dict[str, Any],
        dataset: Dataset,
        val_dataset: Dataset,
        class_names: List[str],
        device: str = "cuda",
    ):
        self.cfg = cfg
        self.dataset = dataset
        self.val_dataset = val_dataset
        self.class_names = class_names
        self.device = device
        self.num_classes = len(class_names)

        # ── CLIP (frozen) ──────────────────────────────────
        self.clip = CLIPEncoder(
            model_name=cfg["model"]["clip_model"].replace("/", "-"),
            pretrained=cfg["model"]["clip_pretrained"],
            device=device,
        )

        # ── Task classifier ────────────────────────────────
        self.classifier = TaskClassifier(
            clip_model=cfg["model"]["clip_model"],
            pretrained=cfg["model"]["clip_pretrained"],
            num_classes=self.num_classes,
        ).to(device)

        # ── Heads ──────────────────────────────────────────
        state_dim = cfg["scheduler"]["state_dim"]
        self.aug_head = AugmentationHead(state_dim=state_dim).to(device)
        self.query_head = QueryHead(state_dim=state_dim).to(device)

        # ── Augmentation module ────────────────────────────
        sd_aug = None
        if cfg["augmentation"].get("sd_model"):
            try:
                from .augmentation import StableDiffusionAugmentation
                sd_aug = StableDiffusionAugmentation(
                    cfg["augmentation"]["sd_model"], device=device
                )
            except Exception as e:
                print(f"[SAGE] Stable Diffusion not loaded ({e}); using conv aug only.")
        self.aug_module = SemanticUtilityAugmentation(
            self.clip, self.aug_head, sd_aug=sd_aug, device=device
        )

        # ── Query utility ──────────────────────────────────
        self.query_module = LearnedQueryUtility(self.clip, self.query_head, device)

        # ── RL Scheduler ───────────────────────────────────
        sched_cfg = cfg["scheduler"]
        self.scheduler = AdaptiveBudgetScheduler(
            state_dim=sched_cfg["state_dim"],
            hidden_dim=sched_cfg["hidden_dim"],
            lr_actor=sched_cfg["lr_actor"],
            lr_critic=sched_cfg["lr_critic"],
            gamma=sched_cfg["gamma"],
            clip_eps=sched_cfg["clip_eps"],
            ppo_epochs=sched_cfg["ppo_epochs"],
            beta=sched_cfg["beta"],
            eta=sched_cfg["eta"],
            device=device,
        )

        # ── Optimiser for classifier + heads ───────────────
        self.optimizer = optim.AdamW(
            list(self.classifier.parameters())
            + list(self.aug_head.parameters())
            + list(self.query_head.parameters()),
            lr=cfg["training"]["lr"],
            weight_decay=cfg["training"]["weight_decay"],
        )

        # ── Active learning state ──────────────────────────
        N = len(dataset)
        init_n = cfg["active_learning"]["initial_labels"]
        all_indices = list(range(N))
        random.shuffle(all_indices)

        self.labeled_indices: List[int] = all_indices[:init_n]
        self.unlabeled_indices: List[int] = all_indices[init_n:]
        self.budget: int = cfg["active_learning"]["budget"]
        self.total_budget: int = self.budget
        self.rounds: int = cfg["active_learning"]["rounds"]

        self.history: List[Dict] = []

    # ──────────────────────────────────────────────────────
    # Main training loop
    # ──────────────────────────────────────────────────────

    def run(self):
        val_loader = DataLoader(
            self.val_dataset,
            batch_size=self.cfg["training"]["batch_size"],
            shuffle=False,
            num_workers=4,
            pin_memory=True,
        )

        prev_acc = 0.0

        for t in range(self.rounds):
            if self.budget <= 0 or len(self.unlabeled_indices) == 0:
                print("[SAGE] Budget exhausted or pool empty. Stopping.")
                break

            print(f"\n{'─'*55}")
            print(f"  Round {t+1}/{self.rounds} | "
                  f"Budget left: {self.budget}/{self.total_budget} | "
                  f"|L|={len(self.labeled_indices)} | "
                  f"|U|={len(self.unlabeled_indices)}")
            print(f"{'─'*55}")

            # ── 0. Build round-state feature ───────────────
            mean_ent = self._mean_entropy(val_loader)
            rho_cls = self._class_balance_ratio()
            phi_t = build_round_state(
                acc=prev_acc,
                delta_acc=0.0,            # will be updated after training
                mean_entropy=mean_ent,
                budget_remaining=self.budget,
                budget_total=self.total_budget,
                n_labeled=len(self.labeled_indices),
                n_total=len(self.dataset),
                rho_cls=rho_cls,
            ).to(self.device)

            # ── 1. Scheduler → action ──────────────────────
            alpha_t, b_t, p_t = self.scheduler.act(phi_t, self.budget)
            b_t = min(b_t, self.budget, len(self.unlabeled_indices))
            print(f"  α_t={alpha_t:.3f}  b_t={b_t}  p_t={p_t:.3f}")

            # ── 2. Train classifier with augmentation ───────
            mean_w = self._train_round(phi_t, alpha_t)

            # ── 3. Evaluate before query ────────────────────
            acc_before = compute_accuracy(self.classifier, val_loader, self.device)

            # ── 4. Query selection ──────────────────────────
            selected_local = self._query(b_t, p_t, phi_t)
            selected_global = [self.unlabeled_indices[i] for i in selected_local]

            # ── 5. Update labeled / unlabeled sets ──────────
            self.labeled_indices.extend(selected_global)
            for idx in sorted(selected_local, reverse=True):
                self.unlabeled_indices.pop(idx)
            self.budget -= b_t

            # ── 6. Re-train with new labels ─────────────────
            mean_w_post = self._train_round(phi_t, alpha_t)

            # ── 7. Evaluate after query ─────────────────────
            acc_after = compute_accuracy(self.classifier, val_loader, self.device)
            delta_acc = acc_after - acc_before
            prev_acc = acc_after

            # ── 8. Reward → RL update ───────────────────────
            reward = compute_reward(
                delta_acc=delta_acc,
                b_t=b_t,
                mean_w=mean_w_post,
                beta=self.cfg["scheduler"]["beta"],
                eta=self.cfg["scheduler"]["eta"],
            )
            self.scheduler.store_reward(reward)
            self.scheduler.update()

            print(f"  Acc: {acc_before:.4f} → {acc_after:.4f} | "
                  f"ΔAcc={delta_acc:+.4f} | reward={reward:.4f}")

            record = dict(
                round=t + 1,
                acc=acc_after,
                delta_acc=delta_acc,
                reward=reward,
                b_t=b_t,
                alpha_t=alpha_t,
                p_t=p_t,
                mean_w=mean_w_post,
                budget_remaining=self.budget,
                n_labeled=len(self.labeled_indices),
            )
            self.history.append(record)

            # ── 9. Checkpoint ────────────────────────────────
            if (t + 1) % self.cfg["output"].get("save_every", 1) == 0:
                self._save(t + 1)

        print("\n[SAGE] Training complete.")
        return self.history

    # ──────────────────────────────────────────────────────
    # Internal helpers
    # ──────────────────────────────────────────────────────

    def _train_round(self, phi_t: torch.Tensor, alpha_t: float) -> float:
        """Train classifier for epochs_per_round; returns mean aug weight."""
        cfg = self.cfg
        loader = DataLoader(
            Subset(self.dataset, self.labeled_indices),
            batch_size=cfg["training"]["batch_size"],
            shuffle=True,
            num_workers=4,
            pin_memory=True,
            drop_last=True,
        )

        self.classifier.train()
        self.aug_head.train()

        all_mean_w: List[float] = []
        for epoch in range(cfg["training"]["epochs_per_round"]):
            for images, labels in loader:
                images = images.to(self.device)
                labels = labels.to(self.device)

                loss, mean_w = self.aug_module.compute_aug_loss(
                    classifier=self.classifier,
                    images=images,
                    labels=labels,
                    class_names=self.class_names,
                    phi_t=phi_t,
                    alpha_t=alpha_t,
                    M_t=cfg["augmentation"]["M_t"],
                    lambda_aug=cfg["augmentation"]["lambda_aug"],
                )
                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(
                    list(self.classifier.parameters())
                    + list(self.aug_head.parameters()), 1.0
                )
                self.optimizer.step()
                all_mean_w.append(mean_w)

        return float(sum(all_mean_w) / max(len(all_mean_w), 1))

    def _query(self, b_t: int, p_t: float, phi_t: torch.Tensor) -> List[int]:
        """Select b_t samples from the unlabeled pool."""
        pool = Subset(self.dataset, self.unlabeled_indices)
        loader = DataLoader(
            pool,
            batch_size=self.cfg["training"]["batch_size"] * 2,
            shuffle=False,
            num_workers=4,
            pin_memory=True,
        )

        images_list, labels_list = [], []
        for imgs, lbls in loader:
            images_list.append(imgs)
            labels_list.append(lbls)
        all_images = torch.cat(images_list, dim=0).to(self.device)

        selected = self.query_module.select(
            images=all_images,
            classifier=self.classifier,
            class_names=self.class_names,
            phi_t=phi_t,
            b_t=b_t,
            p_t=p_t,
        )
        return selected

    @torch.no_grad()
    def _mean_entropy(self, loader) -> float:
        self.classifier.eval()
        entropies = []
        for x, _ in loader:
            x = x.to(self.device)
            logits = self.classifier(x)
            probs = torch.softmax(logits, dim=-1).clamp(min=1e-8)
            h = -(probs * probs.log()).sum(dim=-1)
            entropies.extend(h.tolist())
        return float(sum(entropies) / max(len(entropies), 1))

    def _class_balance_ratio(self) -> float:
        """
        ρ_cls: fraction of classes with ≥1 labeled sample.
        """
        labeled_labels = [self.dataset[i][1] for i in self.labeled_indices]
        unique = len(set(labeled_labels))
        return unique / self.num_classes

    def _save(self, round_idx: int):
        out_dir = self.cfg["output"]["dir"]
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, f"sage_round{round_idx:03d}.pt")
        torch.save({
            "round": round_idx,
            "classifier": self.classifier.state_dict(),
            "aug_head": self.aug_head.state_dict(),
            "query_head": self.query_head.state_dict(),
            "scheduler": self.scheduler.state_dict(),
            "labeled_indices": self.labeled_indices,
            "budget": self.budget,
            "history": self.history,
        }, path)
        print(f"  [ckpt] saved → {path}")
