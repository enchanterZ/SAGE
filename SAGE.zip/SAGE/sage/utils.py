"""
sage/utils.py
Shared CLIP embedding utilities, dataset helpers, and evaluation metrics.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F
import open_clip
from typing import List, Optional


# ──────────────────────────────────────────────
# CLIP wrapper
# ──────────────────────────────────────────────

class CLIPEncoder:
    """
    Wraps a frozen OpenCLIP model.
    Provides:
      v(x)  — L2-normalised visual embedding  (Eq. 2)
      u(c)  — L2-normalised text  embedding for class c (Eq. 2)
    """

    def __init__(self, model_name: str = "ViT-B-32", pretrained: str = "openai",
                 device: str = "cuda"):
        self.device = device
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained
        )
        self.tokenizer = open_clip.get_tokenizer(model_name)
        self.model.eval().to(device)
        for p in self.model.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def visual(self, images: torch.Tensor) -> torch.Tensor:
        """
        Args:
            images: (N, C, H, W) pre-processed tensor
        Returns:
            v: (N, D) L2-normalised image embeddings   [Eq. 2]
        """
        z = self.model.encode_image(images.to(self.device))
        return F.normalize(z, dim=-1)

    @torch.no_grad()
    def textual(self, class_names: List[str]) -> torch.Tensor:
        """
        Args:
            class_names: list of C class name strings
        Returns:
            u: (C, D) L2-normalised text embeddings    [Eq. 2]
        """
        prompts = [f"a photo of a {c}" for c in class_names]
        tokens = self.tokenizer(prompts).to(self.device)
        t = self.model.encode_text(tokens)
        return F.normalize(t, dim=-1)

    @torch.no_grad()
    def max_class_sim(self, v: torch.Tensor, u: torch.Tensor) -> torch.Tensor:
        """
        A_abs(x) = max_c cos(v(x), u(c))              [Eq. 14]
        Args:
            v: (N, D)
            u: (C, D)
        Returns:
            (N,) tensor of max cosine similarities
        """
        sim = v @ u.T                                  # (N, C)
        return sim.max(dim=-1).values


# ──────────────────────────────────────────────
# Cosine similarity helpers
# ──────────────────────────────────────────────

def cosine(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Element-wise cosine similarity between two sets of vectors."""
    return F.cosine_similarity(a, b, dim=-1)


def pairwise_cosine(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """
    Args:
        a: (N, D)
        b: (M, D)
    Returns:
        (N, M) cosine similarity matrix
    """
    return F.normalize(a, dim=-1) @ F.normalize(b, dim=-1).T


# ──────────────────────────────────────────────
# Evaluation
# ──────────────────────────────────────────────

@torch.no_grad()
def compute_accuracy(model: torch.nn.Module, loader, device: str) -> float:
    model.eval()
    correct = total = 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        preds = model(x).argmax(dim=-1)
        correct += (preds == y).sum().item()
        total += len(y)
    return correct / total if total > 0 else 0.0


@torch.no_grad()
def compute_entropy(logits: torch.Tensor) -> torch.Tensor:
    """
    H(x) = -sum_c p(c|x) log p(c|x)                  [Eq. 15]
    Args:
        logits: (N, C)
    Returns:
        (N,) entropy values
    """
    probs = torch.softmax(logits, dim=-1).clamp(min=1e-8)
    return -(probs * probs.log()).sum(dim=-1)


# ──────────────────────────────────────────────
# Round-state feature
# ──────────────────────────────────────────────

def build_round_state(
    acc: float,
    delta_acc: float,
    mean_entropy: float,
    budget_remaining: float,
    budget_total: float,
    n_labeled: int,
    n_total: int,
    rho_cls: float,
) -> torch.Tensor:
    """
    s_t = [A_cc, ΔA_cc, H̄, B_t/B, |L_t|/N, ρ_cls]   [Eq. 3]
    Returns: (6,) float tensor
    """
    return torch.tensor([
        acc,
        delta_acc,
        mean_entropy,
        budget_remaining / max(budget_total, 1),
        n_labeled / max(n_total, 1),
        rho_cls,
    ], dtype=torch.float32)
