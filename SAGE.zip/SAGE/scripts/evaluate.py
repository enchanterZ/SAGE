"""
scripts/evaluate.py
Evaluate a saved SAGE checkpoint on the test set.

Usage:
    python scripts/evaluate.py \
        --config configs/cub200.yaml \
        --checkpoint outputs/cub200/sage_round010.pt
"""

import argparse
import os
import sys
import yaml
import torch
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sage.model import TaskClassifier
from sage.utils import compute_accuracy
from sage.datasets import build_dataset


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=str, required=True)
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--device", type=str, default="cuda")
    return p.parse_args()


def main():
    args = parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    device = args.device if torch.cuda.is_available() else "cpu"

    _, val_dataset, class_names = build_dataset(cfg)
    val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False,
                            num_workers=4, pin_memory=True)

    model = TaskClassifier(
        clip_model=cfg["model"]["clip_model"],
        pretrained=cfg["model"]["clip_pretrained"],
        num_classes=len(class_names),
    ).to(device)

    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt["classifier"])
    print(f"[eval] Loaded checkpoint from round {ckpt['round']}")

    acc = compute_accuracy(model, val_loader, device)
    print(f"[eval] Accuracy: {acc:.4f} ({acc*100:.2f}%)")
    print(f"[eval] Labeled samples used: {len(ckpt['labeled_indices'])}")


if __name__ == "__main__":
    main()
