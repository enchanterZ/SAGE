"""
scripts/train.py
Entry point for SAGE active learning training.

Usage:
    python scripts/train.py --config configs/cub200.yaml --budget 1000 --seed 42
"""

import argparse
import random
import os
import sys
import yaml
import torch
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sage.trainer import SAGETrainer
from sage.datasets import build_dataset          # see below


def parse_args():
    p = argparse.ArgumentParser(description="SAGE Active Learning Trainer")
    p.add_argument("--config", type=str, required=True,
                   help="Path to YAML config file")
    p.add_argument("--budget", type=int, default=None,
                   help="Override total annotation budget B")
    p.add_argument("--rounds", type=int, default=None,
                   help="Override number of AL rounds")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", type=str, default="cuda")
    return p.parse_args()


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def main():
    args = parse_args()
    set_seed(args.seed)

    # ── Load config ────────────────────────────────────────
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    if args.budget is not None:
        cfg["active_learning"]["budget"] = args.budget
    if args.rounds is not None:
        cfg["active_learning"]["rounds"] = args.rounds

    device = args.device if torch.cuda.is_available() else "cpu"
    print(f"[SAGE] Device: {device}")
    print(f"[SAGE] Config: {args.config}")
    print(f"[SAGE] Budget: {cfg['active_learning']['budget']} | "
          f"Rounds: {cfg['active_learning']['rounds']}")

    # ── Datasets ───────────────────────────────────────────
    train_dataset, val_dataset, class_names = build_dataset(cfg)

    # ── Run ────────────────────────────────────────────────
    trainer = SAGETrainer(
        cfg=cfg,
        dataset=train_dataset,
        val_dataset=val_dataset,
        class_names=class_names,
        device=device,
    )
    history = trainer.run()

    # ── Summary ────────────────────────────────────────────
    print("\n[SAGE] === Run Summary ===")
    for r in history:
        print(f"  Round {r['round']:02d} | "
              f"Acc={r['acc']:.4f} | "
              f"b_t={r['b_t']} | "
              f"α={r['alpha_t']:.3f} | "
              f"reward={r['reward']:+.4f}")
    best = max(history, key=lambda x: x["acc"])
    print(f"\n  Best Acc: {best['acc']:.4f} at Round {best['round']}")


if __name__ == "__main__":
    main()
